package br.edu.ifrn.siteifsol.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.siteifsol.dominio.Usuario;
import br.edu.ifrn.siteifsol.repository.Usuariorepository;

@Controller
@RequestMapping("/usuario")
public class CadastroUsuarioController {

	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("usuario", new Usuario());
		return "Cadastro";
	}
    @Autowired
	private Usuariorepository usuarioRepository;
	
	@SuppressWarnings("unchecked")
	@PostMapping("/salvar")
	public String salvar(Usuario usuario, Model model, RedirectAttributes attr, HttpSession sessao) {

		List<String> msgValidacao = validarDados(usuario);

		   //criptografando a senha
		String senhaCriptografada = new BCryptPasswordEncoder().encode(usuario.getSenha());
		usuario.setSenha(senhaCriptografada);
				
		
		       //Já serve para cadastro e edição
				usuarioRepository.save(usuario);
				attr.addFlashAttribute("msgsSucesso","O peração realizada com sucesso!");
				
				return "redirect:/usuario/cadastro";
	}

	@ModelAttribute("situacao")
	public List<String> getSituacao() {
		return Arrays.asList("Docente", "Bolsista", "Voluntário");
	}

	private List<String> validarDados(Usuario usuario) {

		List<String> msgs = new ArrayList<>();

		if (usuario.getNome() == null || usuario.getNome().isEmpty()) {
			msgs.add("O campo nome é obrigatório");
		}
		if (usuario.getNome().length() <= 5) {
			msgs.add("Nome inválido");
		}
		if (usuario.getEmail() == null || usuario.getEmail().isEmpty()) {
			msgs.add("O campo Email é obrigatório");
		}
		if (usuario.getSituacao() == null || usuario.getSituacao().isEmpty()) {
			msgs.add("O campo Profissão é obrigatório");
		}
		if (usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
			msgs.add("O campo senha é obrigatório");
		}
		if (usuario.getSenha().length() <= 6) {
			msgs.add("Sua senha precisar ter no minimo 6 caracteres");
		}

		return msgs;
	}

}
