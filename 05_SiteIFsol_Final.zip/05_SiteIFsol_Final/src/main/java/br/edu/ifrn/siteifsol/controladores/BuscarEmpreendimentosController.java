package br.edu.ifrn.siteifsol.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.siteifsol.dominio.Usuario;
import br.edu.ifrn.siteifsol.dominio.empreendimento;
import br.edu.ifrn.siteifsol.repository.empreendimentorepository;

@Controller
@RequestMapping("/usuarios")
public class BuscarEmpreendimentosController {
	@GetMapping("/buscaem")
	public String entrarBusca() {
		return "/buscaem";
	}

	@Autowired
	private empreendimentorepository empreendimentosrepository;

	@SuppressWarnings("unchecked")
	@GetMapping("/buscaempre")
	public String buscaempre(@RequestParam(name = "nome", required = false) String nome,
			@RequestParam(name = "email", required = false) String email,
			@RequestParam(name = "mostrarTodosDados", required = false) Boolean mostrarTodosDados, HttpSession sessao,
			ModelMap model) {

		List<empreendimento> empreendimentosEncontrados = empreendimentosrepository.findByEmailAndNome(email, nome);

		model.addAttribute("empreendimentosEncontrados", empreendimentosEncontrados);

		if (mostrarTodosDados != null) {
			model.addAttribute("mostrarTodosDados", true);
		}
		return "/buscaem";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/edita/{id}")
	public String iniciarEdição(@PathVariable("id") Integer idempre, ModelMap model, HttpSession sessao) {

		empreendimento u = empreendimentosrepository.findById(idempre).get();

		model.addAttribute("empre", u);

		return "/CadastroEmpre";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/remove/{id}")
	public String remover(@PathVariable("id") Integer idempree, HttpSession sessao, RedirectAttributes attr) {
		
		empreendimentosrepository.deleteById(idempree);
		attr.addAttribute("msgSucesso", "Usuario removido com sucesso!");

		return "redirect:/usuarios/buscaem";
	}
}
