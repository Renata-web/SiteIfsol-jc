package br.edu.ifrn.siteifsol.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.siteifsol.dominio.Usuario;
import br.edu.ifrn.siteifsol.repository.Usuariorepository;

@Controller
@RequestMapping("/usuarios")
public class BuscaUsuarioController {

	@GetMapping("/busca")
	public String entrarBusca() {
		return "/busca";
	}
	
	@Autowired
	private Usuariorepository usuarioRepository;

	@SuppressWarnings("unchecked")
	@GetMapping("/buscar")
	public String buscar(@RequestParam(name = "nome", required = false) String nome,@RequestParam(name = "email", required = false) String email,
			@RequestParam(name = "mostrarTodosDados", required = false) Boolean mostrarTodosDados, HttpSession sessao,
			ModelMap model) {

      List<Usuario> usuariosEncontrados = usuarioRepository.findByEmailAndNome(email, nome);
		
		model.addAttribute("usuariosEncontrados",usuariosEncontrados);
		
		if(mostrarTodosDados != null) {
			model.addAttribute("mostrarTodosDados",true);
		}
		return "/busca";
	}

	@GetMapping("/editar/{id}")
	public String iniciarEdição(@PathVariable("id") Integer idUsuario, ModelMap model, HttpSession sessao) {


		Usuario u = usuarioRepository.findById(idUsuario).get();

	    
	    model.addAttribute("usuario", u);

		return "/cadastro";
	}

	@ModelAttribute("situacao")
	public List<String> getSituacao() {
		return Arrays.asList("Docente", "Bolsista", "Voluntário");
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/remover/{id}")
	public String remover(@PathVariable("id") Integer idUsuario, HttpSession sessao, RedirectAttributes attr) {

		usuarioRepository.deleteById(idUsuario);
		attr.addAttribute("msgSucesso", "Usuario removido com sucesso!");

		return "redirect:/usuarios/busca";
	}

}
