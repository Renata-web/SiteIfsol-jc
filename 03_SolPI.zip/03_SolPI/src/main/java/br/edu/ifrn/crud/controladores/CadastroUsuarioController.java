package br.edu.ifrn.crud.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.Usuario;

@Controller
@RequestMapping("/usuario")
public class CadastroUsuarioController {
	
	@GetMapping("/cadastro")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("usuario", new Usuario());
		return "Cadastro";
	}
	@SuppressWarnings("unchecked")
	@PostMapping("/salvar")
	public String salvar(Usuario usuario,Model model ,RedirectAttributes attr, HttpSession sessao) {
		
		
		// pegando valores da session
		Integer id = (Integer) sessao.getAttribute("id");
		List<Usuario> usuariosCadastrados = (List<Usuario>)
				sessao.getAttribute("usuariosCadastrados");
		
		if(id == null) {
			id = 1;
		}
		
		if(usuariosCadastrados == null) {
			usuariosCadastrados = new ArrayList<>();
		}
		
		if(usuario.getId() == 0) {
		
		usuario.setId(id);
		usuariosCadastrados.add(usuario);
		
		id++;
		sessao.setAttribute("id", id);
		sessao.setAttribute("usuariosCadastrados", usuariosCadastrados);
		
		attr.addFlashAttribute("msgSucesso", "Cadastro realizado com sucesso");
		}else {
			//edição
			usuariosCadastrados.remove(usuario);
			usuariosCadastrados.add(usuario);
			
			attr.addFlashAttribute("msgSucesso", "Edição realizada com sucesso");
		}
		
		return "redirect:/usuario/cadastro";
	}
	
	
	
	@ModelAttribute("profissao")
	public List<String> getProfissoes(){
		return Arrays.asList("professor", "Medico", "Emfermeira","Programador","outra");
	}
	

}
