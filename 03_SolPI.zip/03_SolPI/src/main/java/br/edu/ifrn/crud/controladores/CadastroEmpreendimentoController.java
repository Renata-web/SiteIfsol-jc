package br.edu.ifrn.crud.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.empreendimento;

@Controller
@RequestMapping("/usuario")
public class CadastroEmpreendimentoController {
	
	@GetMapping("/cadastroem")
	public String entrarCadastro(ModelMap model) {
		model.addAttribute("empre", new empreendimento());
		return "CadastroEmpre";
	}
	@SuppressWarnings("unchecked")
	@PostMapping("/salva")
	public String salvar(empreendimento empre,Model model ,RedirectAttributes attr, HttpSession sessao) {
		
		
		// pegando valores da session
		Integer id = (Integer) sessao.getAttribute("id");
		List<empreendimento> empreendimentosCadastrados = (List<empreendimento>)
				sessao.getAttribute("empreendimentosCadastrados");
		
		if(id == null) {
			id = 1;
		}
		
		if(empreendimentosCadastrados == null) {
			empreendimentosCadastrados = new ArrayList<>();
		}
		
		if(empre.getId() == 0) {
		
		empre.setId(id);
		empreendimentosCadastrados.add(empre);
		
		id++;
		sessao.setAttribute("id", id);
		sessao.setAttribute("empreendimentosCadastrados", empreendimentosCadastrados);
		
		attr.addFlashAttribute("msgSucesso", "Cadastro realizado com sucesso");
		}else {
			//edição
			empreendimentosCadastrados.remove(empre);
			empreendimentosCadastrados.add(empre);
			
			attr.addFlashAttribute("msgSucesso", "Edição realizada com sucesso");
		}
		
		return "redirect:/usuario/cadastroem";
	}

}
