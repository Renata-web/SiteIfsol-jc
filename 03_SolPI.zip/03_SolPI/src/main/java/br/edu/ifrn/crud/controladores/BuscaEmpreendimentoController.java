package br.edu.ifrn.crud.controladores;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.edu.ifrn.crud.dominio.empreendimento;

@Controller
@RequestMapping("/usuarios")
public class BuscaEmpreendimentoController {
	
	@GetMapping("/buscaem")
	public String entrarBusca() {
		return "/buscaem";
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/buscaempre")
	public String buscaempre( @RequestParam(name="nome", required=false ) String nome,
			@RequestParam(name ="mostrarTodosDados", required=false) Boolean mostrarTodosDados,
			HttpSession sessao, ModelMap model) {
	
		//obtem a lsta dos ususario salvos na memoria
				List<empreendimento> empreendimentosCadastrados = (List<empreendimento>)
				sessao.getAttribute("empreendimentosCadastrados");
		
		List<empreendimento> empreendimentosEncontrados = new ArrayList<>();
		
		if(nome == null || nome.isEmpty()) {
		
			empreendimentosEncontrados = empreendimentosCadastrados;
			
		} else {
			
			if(empreendimentosCadastrados != null) {
				
				empreendimentosEncontrados = empreendimentosCadastrados.stream().filter(u -> u.getNome().toLowerCase().contains(
						nome.toLowerCase())).collect(Collectors.toList());
			}
			

		}
		 model.addAttribute("empreendimentosEncontrados", empreendimentosEncontrados);
		 
		 if(mostrarTodosDados != null) {
			 model.addAttribute("mostrarTodosDados", true);
		 }
		
		return "/buscaem";
	}
	
	@SuppressWarnings("unchecked")
	@GetMapping("/edita/{id}")
	public String iniciarEdição(@PathVariable("id") Integer idempre, ModelMap model, HttpSession sessao) {
		
		List<empreendimento> empreendimentosCadastrados = (List<empreendimento>) sessao.getAttribute("empreendimentosCadastrados");
		
		empreendimento u = new empreendimento();
		u.setId(idempre);
		
		int pos = empreendimentosCadastrados.indexOf(u);
	    u = empreendimentosCadastrados.get(pos);
	    
	    model.addAttribute("empre", u);
	    
	    return "/CadastroEmpre";
	}
	
	
	@SuppressWarnings("unchecked")
	@GetMapping("/remove/{id}")
	public String remover(@PathVariable("id") Integer idempree, HttpSession sessao, RedirectAttributes attr) {
		
		List<empreendimento> empreendimentosCadastrados = (List<empreendimento>) sessao.getAttribute("empreendimentosCadastrados");
		 
		empreendimento u = new empreendimento();
		u.setId(idempree);
		
		boolean removeu = empreendimentosCadastrados.remove(u);
		
		if(removeu) {
			attr.addFlashAttribute("msgSucesso", "empreendimento removido com sucesso");
		}else {
			attr.addFlashAttribute("msgErro", "Naõ foi possivel remover o empreendimento");
		}
		
		return "redirect:/usuarios/buscaem";
	}
	
	
	

}

